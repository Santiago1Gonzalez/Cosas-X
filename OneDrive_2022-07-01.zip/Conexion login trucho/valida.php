<?php
$us=$_POST['user'];
$con=md5($_POST['con']);
        $conexion = new mysqli("localhost", "root", "", "prueba");
        if (isset($_POST['log'])){
            $sql = "SELECT * FROM login where usuario ='$us' && clave ='$con'";
        $consulta = $conexion->query($sql);
        echo mysqli_num_rows($consulta);
        }
        elseif(isset($_POST['reg'])){
            $tipo=$_POST['tipo'];
            $sql = "insert into login values('$us','$con','$tipo')";
        $consulta = $conexion->query($sql);
            echo "exito";
        }
        
    ?>
<br><a href="enc.php">Volver</a>