<?php
$us=$_GET['user'];
$con=md5($_GET['con']);
        $conexion = new mysqli("localhost", "root", "", "prueba");
        if (isset($_GET['log'])){
            $sql = "SELECT * FROM login WHERE usuario ='$us' && clave ='$con'";
        $consulta = $conexion->query($sql);
        echo mysqli_num_rows($consulta);
        }
        elseif(isset($_GET['reg'])){
            $tipo=$_GET['tipo'];
            $sql = "INSERT INTO login VALUES('$us','$con','$tipo')";
        $consulta = $conexion->query($sql);
            echo "exito";
        }
        
    ?>
<br><a href="enc.php">Volver</a>