create DATABASE prueba;
use prueba;
create table login(
usuario varchar(24) PRIMARY KEY,
clave varchar(32),
tipo ENUM("admin","gestor")
);