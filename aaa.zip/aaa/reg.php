<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form action="reg" method="get">
        <input type="text" name="user">Usuario <br>
        <input type="text" name="con"> contraseña <br>
        <input type="text" name="recon"> repetir contraseña <br>
        <select name="tipo" id="">
            <option value="admin">admin</option>
            <option value="gestor">gestor</option>
        </select>
        <input type="submit" value="Registrarse" name="reg">
        <?php
        if (isset($_GET['reg'])) {
            $con=$_GET['con'];
            $recon=$_GET['recon'];
            val($con,$recon);
        }

        function val($temp1,$temp2){
            if(8 <= strlen($temp1) && strlen($temp1) <= 12){
                if($temp1==$temp2){   
                    header('location:http://localhost/aaa/valida.php?user='.$_GET['user'].'&con='.$_GET['con'].'&recon='.$_GET['recon'].'&tipo='.$_GET['tipo'].'&reg='.$_GET['reg']);
                }else{
                    echo "Contraseña debe ser igual en los dos campos";
                }}else{
                    echo "Contraseña debe ser entre 12 y 8 caracteres";
                }
        }
        ?>
    </form>
</body>
</html><?php


?>
